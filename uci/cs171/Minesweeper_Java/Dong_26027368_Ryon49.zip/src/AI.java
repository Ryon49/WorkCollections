package src;

public abstract class AI {	
	public abstract Action getAction(int number);
}
